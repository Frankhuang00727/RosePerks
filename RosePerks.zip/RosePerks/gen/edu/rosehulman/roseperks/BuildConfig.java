/** Automatically generated file. DO NOT MODIFY */
package edu.rosehulman.roseperks;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}